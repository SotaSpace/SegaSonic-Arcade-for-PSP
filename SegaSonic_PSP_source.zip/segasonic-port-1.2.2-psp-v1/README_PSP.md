# SegaSonic The Hedgehog: PSP port, first version (changes on top of segasonic-port-1.2.2)

Licence: BSD 3-Clause, as the original port (see LICENSE). No ROM data and no game assets are included: use your own
ROM dump (`rom/`) and extract the assets with `extract_assets.py`, as the original README says.

This is the source of the first SegaSonic_PSP.zip: automatic picture rate, full resolution, FM at half rate,
built with -O2 -G0. (Source rebuilt from the working tree; not recompiled byte for byte.)

- `ports/psp/`, `ports/sdl2/` (`#ifdef __PSP__`), `CMakeLists.txt` PSP guards: EBOOT/PRX with pspdev (SDL2).
- `runtime/src/sprite_pager.c`, `tools/make_psp_pack.c`: `segasonic.psp` sprite pack (4 KB blocks, LZ4) to fit 24 MB.
  Make it from YOUR assets; do not share it.
- `runtime/src/video.c`, `ym3438.c`, `sound_chips.c`: faster layers/mixer, picture planning, FM at half rate.

Build (pspdev):
    export PSPDEV=/path/to/pspdev PATH=$PSPDEV/bin:$PATH
    cmake -S . -B build/psp -DCMAKE_TOOLCHAIN_FILE=$PSPDEV/psp/share/pspdev.cmake -DCMAKE_BUILD_TYPE=Release -DCMAKE_C_FLAGS_RELEASE="-O2 -G0"
    cmake --build build/psp --target SegaSonic
