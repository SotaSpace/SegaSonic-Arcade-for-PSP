# Name:        psp.cmake
# Description: the PSP build (pspdev's toolchain): the console game alone, as an EBOOT.PBP
# Version:     0.1.0
# Created:     26-10-2026
# Modified:    26-10-2026
#
# Included by CMakeLists.txt when the toolchain is the PSP's (-DCMAKE_TOOLCHAIN_FILE=$PSPDEV/psp/share/pspdev.cmake).
# The game is the same console build as on a computer, through SDL2 for the PSP, with its picture and controls
# fixed (SEGASONIC_HANDHELD), no EXIT in its menu (the HOME button leaves it), one core (no worker threads) and
# its sprites through the pager (S32_NO_SPRITE_ARRAY: runtime/src/sprite_pager.c), as the PSP has 24 MB for the
# game and the sprite chips alone are 16.
# The assets: segasonic.psp, which tools/make_psp_pack.c writes from segasonic.assets on a computer, goes beside
# EBOOT.PBP, in ms0:/PSP/GAME/SegaSonic/ (the player's own, never shared).

target_compile_definitions(sonic_game_console PUBLIC SEGASONIC_HANDHELD SEGASONIC_SYSTEM_EXIT)
target_compile_definitions(s32runtime PUBLIC S32_NO_SPRITE_ARRAY)
target_compile_definitions(sonic_data PUBLIC S32_NO_SPRITE_ARRAY)
target_compile_definitions(sonic_game_console PUBLIC S32_NO_SPRITE_ARRAY)

add_executable(SegaSonic ports/sdl2/main.c ports/sdl2/settings.c ports/sdl2/actions.c)
target_compile_definitions(SegaSonic PRIVATE S32_NO_SPRITE_ARRAY)
# SDL2 for the PSP (pspdev's psp/lib): sdl2-config --cflags --libs
set(SONIC_PSP_SDL2_INCLUDE $ENV{PSPDEV}/psp/include/SDL2)
target_include_directories(SegaSonic PRIVATE ${SONIC_PSP_SDL2_INCLUDE})
target_include_directories(sonic_game_console PRIVATE ${SONIC_PSP_SDL2_INCLUDE})
target_link_libraries(SegaSonic PRIVATE sonic_game_console sonic_data SDL2main SDL2 m GL
	pspvram pspaudio pspvfpu pspdisplay pspgu pspge psphprm pspctrl psppower)

create_pbp_file(
	TARGET SegaSonic
	ICON_PATH ${CMAKE_SOURCE_DIR}/ports/psp/ICON0.PNG
	BACKGROUND_PATH NULL
	PREVIEW_PATH NULL
	TITLE "SegaSonic The Hedgehog"
	BUILD_PRX
	VERSION 01.02)
