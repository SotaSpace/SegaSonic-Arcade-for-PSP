/**
 *    Name:        machine.c
 *    Description: System 32 memory map, interrupt controller, timers, video registers and SegaSonic protection
 *    Version:     0.1.0
 *    Created:     11-10-2026
 *    Modified:    13-10-2026
 *    Author:      Sebastian Toyos
 *
 *    license:BSD-3-Clause
 *    Behavior follows MAME sega/segas32.cpp, segas32_v.cpp and segas32_m.cpp (Aaron Giles).
 */
#include "internal.h"

#include <stdarg.h>
#include <stdio.h>
#include <string.h>

s32_machine s32_board;

void s32_log(const char *format, ...)
{
	char message[256];
	va_list arguments;

	if (!s32_board.log)
		return;
	va_start(arguments, format);
	vsnprintf(message, sizeof(message), format, arguments);
	va_end(arguments);
	s32_board.log(message);
}

static inline uint16_t load16(const uint8_t *source)
{
	return (uint16_t)(source[0] | (source[1] << 8));
}

static inline void store16(uint8_t *dest, uint16_t data, uint16_t mask)
{
	if (mask & 0x00ff)
		dest[0] = (uint8_t)data;
	if (mask & 0xff00)
		dest[1] = (uint8_t)(data >> 8);
}

/* ---- interrupt controller (0xD00000) ---- */

static uint8_t pending_irqs(void)
{
	return s32_board.irq_control[7] & ~s32_board.irq_control[6] & 0x1f;
}

static void update_irq(void)
{
	if (s32_board.irq_changed)
		s32_board.irq_changed(pending_irqs() != 0);
}

void s32_signal_irq(int source)
{
	if (source >= 0 && source < 5)
		s32_board.irq_control[7] |= (uint8_t)(1u << source);
	update_irq();
}

bool s32_irq_asserted(void)
{
	return pending_irqs() != 0;
}

uint8_t s32_irq_acknowledge(void)
{
	const uint8_t pending = pending_irqs();

	for (int source = 0; source < 5; source++)
		if (pending & (1u << source))
			return s32_board.irq_control[source];
	return 0;
}

static void update_next_timer(void)
{
	s32_board.next_timer = UINT64_MAX;
	for (int which = 0; which < 2; which++)
		if (s32_board.timer_deadline[which] && s32_board.timer_deadline[which] < s32_board.next_timer)
			s32_board.next_timer = s32_board.timer_deadline[which];
}

static void start_timer(int which)
{
	uint64_t period;

	if (which == 0)
	{
		const uint16_t duration = s32_board.irq_control[8] | ((s32_board.irq_control[9] << 8) & 0xf00);
		if (!duration)
			return;
		/* 0x800 ticks of 32.2159 MHz / 2 per count: the V60 clock itself */
		period = 0x800ull * duration;
	}
	else
	{
		const uint16_t duration = s32_board.irq_control[10] | ((s32_board.irq_control[11] << 8) & 0xf00);
		if (!duration)
			return;
		/* 0x100 ticks of 50 MHz / 16 per count, converted to V60 cycles */
		period = (0x100ull * duration * S32_CPU_CLOCK + 3124999) / 3125000;
	}
	s32_board.timer_deadline[which] = s32_board.cycles + period;
	update_next_timer();
}

uint64_t s32_next_timer(void)
{
	return s32_board.next_timer;
}

void s32_run_timers(void)
{
	for (int which = 0; which < 2; which++)
	{
		if (s32_board.timer_deadline[which] && s32_board.timer_deadline[which] <= s32_board.cycles)
		{
			s32_board.timer_deadline[which] = 0;
			update_next_timer();
			s32_signal_irq(S32_IRQ_TIMER0 + which);
		}
	}
}

static uint8_t int_control_read(uint32_t offset)
{
	(void)offset;
	return 0xff;    /* MAME does not model the timer count-down read-back either */
}

static void int_control_write(uint32_t offset, uint8_t data)
{
	switch (offset)
	{
		case 0: case 1: case 2: case 3: case 4:    /* vectors */
		case 5:                                      /* unknown */
			s32_board.irq_control[offset] = data;
			break;
		case 6:                                      /* mask */
			s32_board.irq_control[6] = data;
			update_irq();
			break;
		case 7:                                      /* acknowledge */
			s32_board.irq_control[7] &= data;
			update_irq();
			break;
		case 8: case 9:
			s32_board.irq_control[offset] = data;
			start_timer(0);
			break;
		case 10: case 11:
			s32_board.irq_control[offset] = data;
			start_timer(1);
			break;
		default:                                     /* 12-15: interrupt to the sound CPU */
			s32_board.sound_requests++;
			s32_sound_signal_irq(S32_SOUND_IRQ_V60);
			break;
	}
}

/* ---- video ---- */

static uint16_t to_alternate_format(uint16_t value)
{
	/* xBBBBBGGGGGRRRRR -> xBGRBBBBGGGGRRRR */
	const int r = value & 0x1f;
	const int g = (value >> 5) & 0x1f;
	const int b = (value >> 10) & 0x1f;
	uint16_t result = (value & 0x8000) | ((b & 0x01) << 14) | ((g & 0x01) << 13) | ((r & 0x01) << 12);
	return result | ((b & 0x1e) << 7) | ((g & 0x1e) << 3) | ((r & 0x1e) >> 1);
}

static uint16_t from_alternate_format(uint16_t value)
{
	const int r = ((value >> 12) & 0x01) | ((value << 1) & 0x1e);
	const int g = ((value >> 13) & 0x01) | ((value >> 3) & 0x1e);
	const int b = ((value >> 14) & 0x01) | ((value >> 7) & 0x1e);
	return (uint16_t)((value & 0x8000) | (b << 10) | (g << 5) | r);
}

static uint16_t palette_read(uint32_t index)
{
	/* the upper half of the window shows the same entries in the alternate format */
	const uint16_t value = s32_board.palette[index & 0x3fff];
	return (index & 0x4000) ? to_alternate_format(value) : value;
}

static void palette_store(uint32_t index, uint16_t data, uint16_t mask, bool alternate)
{
	uint16_t value = s32_board.palette[index];
	if (alternate)
		value = to_alternate_format(value);
	value = (uint16_t)((value & ~mask) | (data & mask));
	if (alternate)
		value = from_alternate_format(value);
	s32_board.palette[index] = value;
}

static void palette_write(uint32_t index, uint16_t data, uint16_t mask)
{
	const bool alternate = (index & 0x4000) != 0;

	index &= 0x3fff;
	palette_store(index, data, mask, alternate);
	/* with blending enabled, writes go to both halves of palette RAM */
	if (s32_board.mixer[0x4e / 2] & 0x0880)
		palette_store(index ^ 0x2000, data, mask, alternate);
}

static uint8_t sprite_control_read(uint32_t offset)
{
	switch (offset)
	{
		case 0: return (uint8_t)(0xfc | s32_board.sprite_buffer);
		case 1: return 0xfd;                                  /* "normal" render status */
		case 6: return (uint8_t)(0xfc | (s32_board.sprite_control_latched[6] & 1));
		case 7: return 0xfc;
		default: return (uint8_t)(0xfc | s32_board.sprite_control_latched[offset]);
	}
}

uint64_t s32_frame_start(uint64_t frame)
{
	return frame * S32_CPU_CLOCK / S32_FRAME_RATE;
}

uint64_t s32_line_start(uint64_t frame, int line)
{
	return (frame * S32_LINES_PER_FRAME + (uint64_t)line) * S32_CPU_CLOCK / (S32_FRAME_RATE * S32_LINES_PER_FRAME);
}

/* MAME's timing: VBLANK starts at line 224 and ends with the frame; sprites go 50 us later */
static uint64_t next_frame_event(void)
{
	switch (s32_board.frame_phase)
	{
		case 0: return s32_line_start(s32_board.frame, S32_VISIBLE_LINES);
		case 1: return s32_frame_start(s32_board.frame + 1);
		default: return s32_frame_start(s32_board.frame + 1) + S32_CPU_CLOCK / 20000;
	}
}

void s32_wait(void)
{
	const uint64_t event = next_frame_event();

	if (s32_board.time_passes)
		s32_board.time_passes(s32_board.next_timer <= event ? s32_board.next_timer : event);
	if (s32_board.next_timer <= event)
	{
		s32_board.cycles = s32_board.next_timer;
		s32_run_timers();
		return;
	}
	s32_board.cycles = event;
	switch (s32_board.frame_phase)
	{
		case 0:
			s32_vblank_start();
			s32_board.frame_phase = 1;
			break;
		case 1:
			s32_vblank_end();
			s32_board.frame_phase = 2;
			break;
		default:
			s32_sprite_update();
			s32_board.frame++;
			s32_board.frame_phase = 0;
			break;
	}
}

static uint64_t hash_bytes(const void *data, size_t size, uint64_t hash)
{
	const uint8_t *bytes = (const uint8_t *)data;
	for (size_t index = 0; index < size; index++)
		hash = (hash ^ bytes[index]) * 0x100000001b3ull;
	return hash;
}

uint64_t s32_state_hash(void)
{
	uint64_t hash = 0xcbf29ce484222325ull;
	hash = hash_bytes(s32_board.work_ram, S32_STACK_START, hash);
	hash = hash_bytes(s32_board.video_ram, sizeof(s32_board.video_ram), hash);
	hash = hash_bytes(s32_board.sprite_ram, sizeof(s32_board.sprite_ram), hash);
	hash = hash_bytes(s32_board.palette, sizeof(s32_board.palette), hash);
	return hash_bytes(s32_board.mixer, sizeof(s32_board.mixer), hash);
}

void s32_vblank_start(void)
{
	if (s32_board.frame_shown)
		s32_board.frame_shown();
	/* the game reads and clears the trackball counters right after VBLANK ends: controls that move
	   now are seen whole at the next read */
	if (s32_board.controls_update)
		s32_board.controls_update();
	s32_signal_irq(S32_IRQ_VBLANK_START);
}

void s32_vblank_end(void)
{
	s32_signal_irq(S32_IRQ_VBLANK_END);
}

void s32_sprite_update(void)
{
	bool erase;
	bool draw;

	/* automatic mode renders every frame (control 3 bit 0 = 0) or every other frame */
	if (!(s32_board.sprite_control[3] & 2))
	{
		if (s32_board.sprite_render_count-- == 0)
		{
			s32_board.sprite_control[0] = 3;
			s32_board.sprite_render_count = s32_board.sprite_control[3] & 1;
		}
	}
	erase = (s32_board.sprite_control[0] & 2) != 0;
	draw = (s32_board.sprite_control[0] & 1) != 0;
	if (draw)
	{
		s32_board.sprite_buffer ^= 1;
		memcpy(s32_board.sprite_control_latched, s32_board.sprite_control, sizeof(s32_board.sprite_control_latched));
		s32_board.sprite_lists++;
	}
	s32_board.sprite_control[0] = 0;
	if (s32_board.sprites_due)
		s32_board.sprites_due(erase, draw);
}

/* ---- SegaSonic rev. C protection (FD1149, 317-0213), as reimplemented by MAME ---- */

static void level_load_protection(uint16_t data, uint16_t mask)
{
	uint16_t cleared;
	uint16_t level = 0x0007;

	store16(&s32_board.work_ram[0xe5c4], data, mask);
	cleared = load16(&s32_board.work_ram[0xe5c4]);
	if (cleared != 0)
	{
		/* big-endian level numbers at 0x263A in the program ROM, indexed by levels cleared */
		const uint32_t entry = 0x263a + cleared * 2u - 2;
		if (entry + 1 < S32_PROGRAM_SIZE)
			level = (uint16_t)((s32_board.program[entry] << 8) | s32_board.program[entry + 1]);
	}
	store16(&s32_board.work_ram[0xf06e], level, 0xffff);
	store16(&s32_board.work_ram[0xf0bc], 0, 0xffff);
	store16(&s32_board.work_ram[0xf0be], 0, 0xffff);
}

/* ---- 16-bit bus ---- */

static uint16_t random_read(void)
{
	s32_board.random_state = 1664525u * s32_board.random_state + 1013904223u;
	return (uint16_t)(s32_board.random_state ^ (s32_board.random_state >> 15));
}

static uint16_t unmapped_read(uint32_t address)
{
	if (s32_board.unmapped_reads++ < 64)
		s32_log("unmapped read %06X at PC %06X", address, s32_board.pc);
	return 0xffff;
}

static void unmapped_write(uint32_t address, uint16_t data, uint16_t mask)
{
	if (s32_board.unmapped_writes++ < 64)
		s32_log("unmapped write %06X = %04X & %04X at PC %06X", address, data, mask, s32_board.pc);
}

static uint16_t bus_read(uint32_t address, uint16_t mask)
{
	address &= 0xfffffe;
	switch (address >> 20)
	{
		case 0x0: case 0x1:
			return load16(&s32_board.program[address]);
		case 0x2:
			return load16(&s32_board.work_ram[address & 0xffff]);
		case 0x3:
			return load16(&s32_board.video_ram[address & 0x1ffff]);
		case 0x4:
			return load16(&s32_board.sprite_ram[address & 0x1ffff]);
		case 0x5:
			return 0xff00 | sprite_control_read((address >> 1) & 7);
		case 0x6:
			if (address & 0x10000)
				return s32_board.mixer[(address >> 1) & 0x3f];
			return palette_read((address >> 1) & 0x7fff);
		case 0x7:
			return load16(&s32_board.shared_ram[address & 0x1fff]);
		case 0xc:
			return 0xff00 | s32_io_read(address & 0x7f);
		case 0xd:
			if (address < 0xd80000)
				return (uint16_t)(int_control_read(address & 0xf) | (int_control_read((address & 0xf) + 1) << 8));
			return random_read();
		case 0xf:
			return load16(&s32_board.program[address & 0xfffff]);
		default:
			(void)mask;
			return unmapped_read(address);
	}
}

static void bus_write(uint32_t address, uint16_t data, uint16_t mask)
{
	address &= 0xfffffe;
	switch (address >> 20)
	{
		case 0x2:
			if (address == 0x20e5c4)
				level_load_protection(data, mask);
			else
				store16(&s32_board.work_ram[address & 0xffff], data, mask);
			break;
		case 0x3:
			store16(&s32_board.video_ram[address & 0x1ffff], data, mask);
			break;
		case 0x4:
			store16(&s32_board.sprite_ram[address & 0x1ffff], data, mask);
			break;
		case 0x5:
			if (mask & 0x00ff)
				s32_board.sprite_control[(address >> 1) & 7] = (uint8_t)data;
			break;
		case 0x6:
			if (address & 0x10000)
			{
				uint16_t *reg = &s32_board.mixer[(address >> 1) & 0x3f];
				*reg = (uint16_t)((*reg & ~mask) | (data & mask));
			}
			else
				palette_write((address >> 1) & 0x7fff, data, mask);
			break;
		case 0x7:
			store16(&s32_board.shared_ram[address & 0x1fff], data, mask);
			break;
		case 0xc:
			if (mask & 0x00ff)
				s32_io_write(address & 0x7f, (uint8_t)data);
			break;
		case 0xd:
			if (address < 0xd80000)
			{
				if (mask & 0x00ff)
					int_control_write(address & 0xf, (uint8_t)data);
				if (mask & 0xff00)
					int_control_write((address & 0xf) + 1, (uint8_t)(data >> 8));
			}
			break;                              /* the random number seed write is ignored */
		case 0x0: case 0x1: case 0xf:
			break;                              /* ROM */
		default:
			unmapped_write(address, data, mask);
			break;
	}
}

/* Wider and unaligned accesses are split into 16-bit bus cycles, the way the V60 drives its bus */

uint8_t s32_read8(uint32_t address)
{
	if (address & 1)
		return (uint8_t)(bus_read(address, 0xff00) >> 8);
	return (uint8_t)bus_read(address, 0x00ff);
}

uint16_t s32_read16(uint32_t address)
{
	if (address & 1)
		return (uint16_t)(s32_read8(address) | (s32_read8(address + 1) << 8));
	return bus_read(address, 0xffff);
}

uint32_t s32_read32(uint32_t address)
{
	if (address & 1)
		return s32_read8(address) | ((uint32_t)s32_read16(address + 1) << 8) | ((uint32_t)s32_read8(address + 3) << 24);
	return s32_read16(address) | ((uint32_t)s32_read16(address + 2) << 16);
}

void s32_write8(uint32_t address, uint8_t data)
{
	if (address & 1)
		bus_write(address, (uint16_t)(data << 8), 0xff00);
	else
		bus_write(address, data, 0x00ff);
}

void s32_write16(uint32_t address, uint16_t data)
{
	if (address & 1)
	{
		s32_write8(address, (uint8_t)data);
		s32_write8(address + 1, (uint8_t)(data >> 8));
	}
	else
		bus_write(address, data, 0xffff);
}

void s32_write32(uint32_t address, uint32_t data)
{
	if (address & 1)
	{
		s32_write8(address, (uint8_t)data);
		s32_write16(address + 1, (uint16_t)(data >> 8));
		s32_write8(address + 3, (uint8_t)(data >> 24));
	}
	else
	{
		s32_write16(address, (uint16_t)data);
		s32_write16(address + 2, (uint16_t)(data >> 16));
	}
}

/* ---- setup ---- */

void s32_reset(void)
{
	memset(s32_board.irq_control, 0xff, sizeof(s32_board.irq_control));
	s32_board.timer_deadline[0] = s32_board.timer_deadline[1] = 0;
	update_next_timer();
	s32_io_reset();
	update_irq();
}

void s32_init(const uint8_t *program)
{
	void (*irq_changed)(bool) = s32_board.irq_changed;
	void (*controls_update)(void) = s32_board.controls_update;
	void (*log)(const char *) = s32_board.log;
	void (*frame_shown)(void) = s32_board.frame_shown;
	void (*sprites_due)(bool, bool) = s32_board.sprites_due;
	void (*time_passes)(uint64_t) = s32_board.time_passes;
	void (*sound_irq_changed)(bool, uint8_t) = s32_board.sound_irq_changed;
	void (*sound_reset_changed)(bool) = s32_board.sound_reset_changed;
	const s32_sound_chips chips = s32_board.chips;
	const uint8_t *sound_rom = s32_board.sound_rom;
	const bool frame_timing = s32_board.frame_timing;

	/* callbacks, the sound chips, the sound ROM and the timing survive; everything else starts from
	   power-on. A saved EEPROM is loaded after this. */
	memset(&s32_board, 0, sizeof(s32_board));
	s32_board.irq_changed = irq_changed;
	s32_board.controls_update = controls_update;
	s32_board.log = log;
	s32_board.frame_shown = frame_shown;
	s32_board.sprites_due = sprites_due;
	s32_board.time_passes = time_passes;
	s32_board.sound_irq_changed = sound_irq_changed;
	s32_board.sound_reset_changed = sound_reset_changed;
	s32_board.chips = chips;
	s32_board.sound_rom = sound_rom;
	s32_board.frame_timing = frame_timing;
	s32_board.program = program;
	memset(s32_board.eeprom.data, 0xff, sizeof(s32_board.eeprom.data));

	/* the wave memory starts all ones, as in MAME's video start */
	memset(s32_board.pcm_ram, 0xff, sizeof(s32_board.pcm_ram));

	/* power-on contents, as in MAME's video start */
	store16(&s32_board.video_ram[0x1ff00], 0x8000, 0xffff);
	memset(s32_board.mixer, 0xff, sizeof(s32_board.mixer));
	s32_board.sprite_buffer = 1;
	s32_board.random_state = 0x9d14abd7;
	s32_board.input.port_a = s32_board.input.port_b = s32_board.input.port_c = 0xff;
	s32_board.input.port_e = s32_board.input.port_f = 0xff;
	s32_reset();
}
