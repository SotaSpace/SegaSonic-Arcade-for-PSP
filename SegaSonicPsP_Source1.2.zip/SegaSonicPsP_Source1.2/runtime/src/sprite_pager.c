/**
 *    Name:        sprite_pager.c
 *    Description: the PSP pack's reader and the sprite blocks' cache (s32/sprite_pager.h)
 *    Version:     0.1.0
 *    Created:     26-10-2026
 *    Modified:    26-10-2026
 *
 *    license:BSD-3-Clause
 *    Format (little endian): "SSPP", u32 version (1), u32 block size (4096), u32 blocks; then an index of
 *    8 bytes a block: u32 offset in the file, u16 stored size, u8 how (0 LZ4, 1 raw, 2 fill), u8 the fill
 *    byte. The blocks are the program (2 MB), the tiles (2 MB), the sound (4 MB) and the sprites (16 MB),
 *    in that order.
 */
#include "s32/sprite_pager.h"
#include "game/data.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define PACK_VERSION 1u
#define HOW_LZ4      0
#define HOW_RAW      1
#define HOW_FILL     2
#define PROGRAM_BLOCKS  (GAME_PROGRAM_SIZE / S32_PAGER_BLOCK)
#define TILES_BLOCKS    (GAME_TILES_SIZE / S32_PAGER_BLOCK)
#define SOUND_BLOCKS    (GAME_SOUND_SIZE / S32_PAGER_BLOCK)
#define TOTAL_BLOCKS    (PROGRAM_BLOCKS + TILES_BLOCKS + SOUND_BLOCKS + S32_PAGER_SPRITE_BLOCKS)

typedef struct
{
	uint32_t offset;
	uint16_t size;
	uint8_t how;
	uint8_t fill;
} entry;

const uint8_t *s32_sprite_pages[S32_PAGER_SPRITE_BLOCKS];

static FILE *pack;
static entry *index_table;
static uint8_t *cache;                 /* slots * 4 KB */
static int32_t *slot_block;            /* the sprite block in each slot, -1 empty */
static unsigned slot_count, hand;
static uint8_t blank_page[2][S32_PAGER_BLOCK];    /* fill blocks of 0xFF and 0x00 the pages point at */
static uint64_t loads, evictions;

int s32_lz4_decode(const uint8_t *source, int source_size, uint8_t *dest, int dest_size)
{
	const uint8_t *in = source, *const in_end = source + source_size;
	uint8_t *out = dest, *const out_end = dest + dest_size;

	while (in < in_end)
	{
		const unsigned token = *in++;
		size_t literals = token >> 4, match;

		if (literals == 15)
		{
			unsigned more;

			do
			{
				if (in >= in_end)
					return -1;
				more = *in++;
				literals += more;
			} while (more == 255);
		}
		if ((size_t)(in_end - in) < literals || (size_t)(out_end - out) < literals)
			return -1;
		memcpy(out, in, literals);
		in += literals;
		out += literals;
		if (in >= in_end)
			break;    /* the last sequence has literals only */
		if (in_end - in < 2)
			return -1;
		{
			const size_t offset = (size_t)in[0] | (size_t)in[1] << 8;

			in += 2;
			if (offset == 0 || offset > (size_t)(out - dest))
				return -1;
			match = token & 15;
			if (match == 15)
			{
				unsigned more;

				do
				{
					if (in >= in_end)
						return -1;
					more = *in++;
					match += more;
				} while (more == 255);
			}
			match += 4;
			if ((size_t)(out_end - out) < match)
				return -1;
			{
				const uint8_t *from = out - offset;

				while (match--)
					*out++ = *from++;    /* (byte by byte: the match may overlap what it writes) */
			}
		}
	}
	return out == out_end ? dest_size : -1;
}

static uint32_t little32(const uint8_t *bytes)
{
	return (uint32_t)bytes[0] | (uint32_t)bytes[1] << 8 | (uint32_t)bytes[2] << 16 | (uint32_t)bytes[3] << 24;
}

/* Block 'number' of the pack decoded into 'dest' (4 KB) */
static bool read_block(uint32_t number, uint8_t *dest)
{
	static uint8_t stored[S32_PAGER_BLOCK + 64];
	const entry *e = &index_table[number];

	if (e->how == HOW_FILL)
	{
		memset(dest, e->fill, S32_PAGER_BLOCK);
		return true;
	}
	if (e->size > sizeof(stored) || fseek(pack, (long)e->offset, SEEK_SET) != 0
		|| fread(stored, 1, e->size, pack) != e->size)
		return false;
	if (e->how == HOW_RAW)
	{
		if (e->size != S32_PAGER_BLOCK)
			return false;
		memcpy(dest, stored, S32_PAGER_BLOCK);
		return true;
	}
	return s32_lz4_decode(stored, e->size, dest, S32_PAGER_BLOCK) == (int)S32_PAGER_BLOCK;
}

const uint8_t *s32_sprite_page_load(uint32_t block)
{
	uint8_t *dest;
	const uint32_t number = PROGRAM_BLOCKS + TILES_BLOCKS + SOUND_BLOCKS + block;
	const entry *e = &index_table[number];

	if (block >= S32_PAGER_SPRITE_BLOCKS)
		return blank_page[0];
	if (e->how == HOW_FILL && (e->fill == 0xFF || e->fill == 0x00))
		return s32_sprite_pages[block] = blank_page[e->fill == 0xFF ? 0 : 1];
	/* (first in, first out: the hand goes round the slots, and the block it finds leaves) */
	if (slot_block[hand] >= 0)
	{
		s32_sprite_pages[slot_block[hand]] = NULL;
		evictions++;
	}
	dest = cache + (size_t)hand * S32_PAGER_BLOCK;
	if (!read_block(number, dest))
		memset(dest, 0xFF, S32_PAGER_BLOCK);    /* (a damaged pack shows blanks rather than stopping) */
	slot_block[hand] = (int32_t)block;
	s32_sprite_pages[block] = dest;
	hand = (hand + 1) % slot_count;
	loads++;
	return dest;
}

void s32_pager_stats(uint64_t *load_count, uint64_t *eviction_count)
{
	if (load_count)
		*load_count = loads;
	if (eviction_count)
		*eviction_count = evictions;
}

static bool load_region(uint8_t *region, uint32_t first, uint32_t blocks)
{
	for (uint32_t i = 0; i < blocks; i++)
		if (!read_block(first + i, region + (size_t)i * S32_PAGER_BLOCK))
			return false;
	return true;
}

pager_result s32_pager_open(const char *path, unsigned slots)
{
	uint8_t head[16];
	uint8_t *raw;

	pack = fopen(path, "rb");
	if (!pack)
		return PAGER_MISSING;
	if (fread(head, 1, sizeof(head), pack) != sizeof(head) || memcmp(head, "SSPP", 4) != 0
		|| little32(head + 4) != PACK_VERSION || little32(head + 8) != S32_PAGER_BLOCK
		|| little32(head + 12) != TOTAL_BLOCKS)
		return PAGER_DAMAGED;
	raw = (uint8_t *)malloc((size_t)TOTAL_BLOCKS * 8);
	index_table = (entry *)malloc(sizeof(entry) * TOTAL_BLOCKS);
	if (!raw || !index_table || fread(raw, 8, TOTAL_BLOCKS, pack) != TOTAL_BLOCKS)
		return PAGER_DAMAGED;
	for (uint32_t i = 0; i < TOTAL_BLOCKS; i++)
	{
		index_table[i].offset = little32(raw + (size_t)i * 8);
		index_table[i].size = (uint16_t)(raw[i * 8 + 4] | raw[i * 8 + 5] << 8);
		index_table[i].how = raw[i * 8 + 6];
		index_table[i].fill = raw[i * 8 + 7];
	}
	free(raw);
	memset(blank_page[0], 0xFF, S32_PAGER_BLOCK);
	memset(blank_page[1], 0x00, S32_PAGER_BLOCK);
	if (!load_region(game_program, 0, PROGRAM_BLOCKS)
		|| !load_region(game_tiles, PROGRAM_BLOCKS, TILES_BLOCKS)
		|| !load_region(game_sound, PROGRAM_BLOCKS + TILES_BLOCKS, SOUND_BLOCKS))
		return PAGER_DAMAGED;
	slot_count = slots ? slots : S32_PAGER_SLOTS;
	cache = (uint8_t *)malloc((size_t)slot_count * S32_PAGER_BLOCK);
	slot_block = (int32_t *)malloc(sizeof(int32_t) * slot_count);
	if (!cache || !slot_block)
		return PAGER_DAMAGED;
	for (unsigned i = 0; i < slot_count; i++)
		slot_block[i] = -1;
	memset(s32_sprite_pages, 0, sizeof(s32_sprite_pages));
	hand = 0;
	loads = evictions = 0;
	return PAGER_OK;
}
