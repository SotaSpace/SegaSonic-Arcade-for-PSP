/**
 *    Name:        sprite_pager.h
 *    Description: the board's sprite chips (16 MB) and the other ROM regions from a block-compressed file, for
 *                 machines with too little memory for them whole (the PSP's)
 *    Version:     0.1.0
 *    Created:     26-10-2026
 *    Modified:    26-10-2026
 *
 *    license:BSD-3-Clause
 *    The PSP pack (tools/make_psp_pack.py) holds the program, tiles and sound regions and the sprites as 4 KB
 *    blocks, each LZ4-compressed, stored raw, or a fill (a block of one byte value: the sprite chips' blank
 *    space is a third of them, and takes no room). The program, tiles and sound are decompressed whole
 *    when the pack opens; the sprites stay in the file, and a block comes into a cache of S32_PAGER_SLOTS
 *    blocks when the video reads from it (the oldest one leaves first). The bytes
 *    are the same ones the full region holds: the frames and the sound are the same.
 *
 *    Not thread safe: the video's worker threads (workers.h) must be none, as on the PSP.
 */
#ifndef S32_SPRITE_PAGER_H
#define S32_SPRITE_PAGER_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define S32_PAGER_BLOCK        4096u
#define S32_PAGER_SPRITE_BLOCKS 4096u        /* 16 MB */
#ifndef S32_PAGER_SLOTS
#define S32_PAGER_SLOTS        512u          /* 2 MB of cache: the game rarely reads from more blocks than that at once */
#endif

/* The resident sprite blocks, by block number: NULL where one has to come from the file */
extern const uint8_t *s32_sprite_pages[S32_PAGER_SPRITE_BLOCKS];

const uint8_t *s32_sprite_page_load(uint32_t block);

/* The sprite chips' byte at 'offset' and the ones after it up to the block's end */
static inline const uint8_t *s32_sprite_bytes(uint32_t offset)
{
	const uint8_t *page = s32_sprite_pages[offset >> 12];

	if (!page)
		page = s32_sprite_page_load(offset >> 12);
	return page + (offset & (S32_PAGER_BLOCK - 1u));
}

typedef enum
{
	PAGER_OK,
	PAGER_MISSING,
	PAGER_DAMAGED
} pager_result;

/* Opens the PSP pack: decompresses the program, tiles and sound (the arrays of game/data.h) and sets up the
   sprites' cache. 'slots' is the cache's size in blocks (0: S32_PAGER_SLOTS). The file stays open */
pager_result s32_pager_open(const char *path, unsigned slots);

/* Blocks the cache has loaded and the reads that found their block resident, for the log */
void s32_pager_stats(uint64_t *loads, uint64_t *evictions);

/* LZ4's block format decoder; the decoded size, or -1 when the input is not a block that size */
int s32_lz4_decode(const uint8_t *source, int source_size, uint8_t *dest, int dest_size);

#ifdef __cplusplus
}
#endif

#endif
