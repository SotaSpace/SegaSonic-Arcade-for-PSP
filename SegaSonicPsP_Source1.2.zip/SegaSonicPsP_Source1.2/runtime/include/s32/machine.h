/**
 *    Name:        machine.h
 *    Description: Sega System 32 board as the SegaSonic program sees it: memory map, interrupts, timers, I/O
 *    Version:     0.1.0
 *    Created:     11-10-2026
 *    Modified:    13-10-2026
 *    Author:      Sebastian Toyos
 *
 *    license:BSD-3-Clause
 *    Behavior follows MAME: sega/segas32.cpp, segas32_v.cpp, segas32_m.cpp (Aaron Giles),
 *    sega/315_5296.cpp (hap), machine/eepromser.cpp and machine/eeprom.cpp (Aaron Giles),
 *    machine/upd4701.cpp. MAME's terms are in tools/reference/mame/LICENSE.
 *
 *    The V60 side is reached through s32_read* / s32_write*: a 16-bit little-endian bus with
 *    24 address lines.
 *
 *    Time runs one of two ways. With cycle timing the caller advances s32_board.cycles as the CPU runs
 *    and calls the frame events itself (tools/reference/s32ref, to follow the real CPU's pace). With
 *    frame timing the program takes no time at all: when it waits for the next frame it calls
 *    s32_wait(), which moves the board to its next event (a timer, the start or end of VBLANK, the
 *    sprite list) and runs it. That is the CPU of a decompiled program, and it never lags.
 */
#ifndef S32_MACHINE_H
#define S32_MACHINE_H

#include <stdbool.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define S32_CPU_CLOCK        16107950u    /* 32.2159 MHz crystal / 2 */
#define S32_FRAME_RATE       60
#define S32_LINES_PER_FRAME  262
#define S32_VISIBLE_LINES    224

#define S32_PROGRAM_SIZE     0x200000
#define S32_WORK_RAM_SIZE    0x10000
#define S32_VIDEO_RAM_SIZE   0x20000
#define S32_SPRITE_RAM_SIZE  0x20000
#define S32_PALETTE_ENTRIES  0x4000
#define S32_MIXER_REGISTERS  0x40
#define S32_SHARED_RAM_SIZE  0x2000
#define S32_EEPROM_WORDS     64

/* The sound board: a Z80 and two YM3438 on 32.2159 MHz / 4, an RF5C68 on 50 MHz / 4 */
#define S32_SOUND_CLOCK      8053975u
#define S32_PCM_CLOCK        12500000u
#define S32_SOUND_ROM_SIZE   0x400000     /* the Z80 program, then the PCM samples it copies */
#define S32_PCM_RAM_SIZE     0x10000      /* the RF5C68's wave memory */

/* Work RAM the V60 stacks use (0x20FE00-0x20FFFF), left out of state comparisons: a decompiled
   program has no V60 stack */
#define S32_STACK_START      0xfe00

/* Interrupt controller sources, highest priority first */
enum
{
	S32_IRQ_VBLANK_START,
	S32_IRQ_VBLANK_END,
	S32_IRQ_SOUND,
	S32_IRQ_TIMER0,
	S32_IRQ_TIMER1
};

/* Sound interrupt controller inputs */
enum
{
	S32_SOUND_IRQ_FM,           /* the first YM3438's timers */
	S32_SOUND_IRQ_V60           /* the V60 writes the interrupt controller's 0x0C-0x0F */
};

/* The sound chips as the Z80 reaches them: the reference plugs in MAME's, the game its own */
typedef struct s32_sound_chips
{
	uint8_t (*fm_read)(int chip, int offset);               /* YM3438 0-1, offsets 0-3 */
	void (*fm_write)(int chip, int offset, uint8_t data);
	void (*pcm_write)(int offset, uint8_t data);            /* RF5C68 registers 0-8 */
	uint8_t (*pcm_memory_read)(int offset);                 /* its 4 KB window on the wave memory */
	void (*pcm_memory_write)(int offset, uint8_t data);
} s32_sound_chips;

/* Controls, active low like the board: a cleared bit is a pressed button */
typedef struct s32_inputs
{
	uint8_t port_a;              /* bit 0: player 1 button, bit 2: player 3 button */
	uint8_t port_b;              /* bit 0: player 2 button */
	uint8_t port_c;
	uint8_t port_e;              /* 0: service, 1: test, 2-3: coins 1-2, 4-5: starts 1-2, 6: coin 3, 7: start 3 */
	uint8_t port_f;              /* 0-3: DIP switches, 4-5: PCB buttons; bit 7 is the EEPROM data line */
	uint16_t trackball_x[3];     /* free-running counters, 12 bits are used */
	uint16_t trackball_y[3];
} s32_inputs;

/* 93C46 serial EEPROM in 16-bit mode */
typedef struct s32_eeprom
{
	uint16_t data[S32_EEPROM_WORDS];
	int state;
	int command;
	int address;
	int bits;
	uint32_t shift;
	uint32_t command_bits;
	bool cs;
	bool clk;
	bool di;
	bool locked;
	uint64_t busy_until;         /* V60 cycle when the internal write or erase ends */
	bool dirty;                  /* contents changed since the last save */
} s32_eeprom;

typedef struct s32_machine
{
	const uint8_t *program;                        /* V60 program image (2 MB), owned by the caller */
	uint8_t work_ram[S32_WORK_RAM_SIZE];
	uint8_t video_ram[S32_VIDEO_RAM_SIZE];          /* 16-bit words, little endian */
	uint8_t sprite_ram[S32_SPRITE_RAM_SIZE];        /* 16-bit words, little endian */
	uint16_t palette[S32_PALETTE_ENTRIES];          /* stored as xBBBBBGGGGGRRRRR */
	uint16_t mixer[S32_MIXER_REGISTERS];
	uint8_t shared_ram[S32_SHARED_RAM_SIZE];        /* shared with the Z80 sound CPU */

	uint8_t sprite_control[8];
	uint8_t sprite_control_latched[8];
	uint8_t sprite_buffer;                          /* bit read back at 0x500000 */
	int sprite_render_count;
	uint32_t sprite_lists;                          /* sprite lists sent to the renderer so far */

	uint8_t irq_control[16];
	uint64_t timer_deadline[2];                     /* cycle when timer 0/1 fires; 0 = stopped */
	uint64_t next_timer;                            /* earliest timer deadline, UINT64_MAX when none */
	uint64_t cycles;                                /* board time, in V60 cycles since reset */
	bool frame_timing;                              /* see the top of this file */
	uint64_t frame;                                 /* frame whose events come next */
	int frame_phase;                                /* frame timing: 0 = VBLANK start next, 1 = its end, 2 = sprites */

	uint8_t io_latch[8];                            /* 315-5296 ports A-H */
	uint8_t io_direction;
	uint8_t io_cnt;
	uint8_t tilebank_external;                      /* port H */
	s32_inputs input;
	uint16_t trackball_start_x[3];                  /* uPD4701 counter origin, set by a reset */
	uint16_t trackball_start_y[3];
	s32_eeprom eeprom;

	const uint8_t *sound_rom;                       /* 4 MB, owned by the caller; set after s32_init */
	uint8_t pcm_ram[S32_PCM_RAM_SIZE];
	uint16_t sound_bank;                            /* the 8 KB page of the sound ROM at Z80 0xA000 */
	uint8_t sound_irq_control[4];                   /* the input of vectors 0-2, and the mask */
	uint8_t sound_irq_input;                        /* pending, by vector */
	uint8_t sound_spare;                            /* the byte at Z80 port 0xF1 */
	uint64_t sound_cycles;                          /* when the Z80's reads and writes happen (board cycles) */
	s32_sound_chips chips;

	uint32_t random_state;
	uint32_t sound_requests;                        /* V60 -> Z80 interrupt requests */
	uint32_t unmapped_reads;
	uint32_t unmapped_writes;
	uint32_t pc;                                    /* instruction being executed, for diagnostics */

	void (*irq_changed)(bool asserted);             /* interrupt line to the V60 */
	void (*controls_update)(void);                  /* when VBLANK starts, where MAME polls the controls */
	void (*frame_shown)(void);                      /* when VBLANK starts: the video draws the frame (MAME's
	                                                   screen update) from the memories as they are */
	void (*sprites_due)(bool erase, bool draw);     /* when the sprite list goes out, once the board took the
	                                                   commands: erase the shown buffer, and swap the buffers
	                                                   and draw the list (with the controls just latched) */
	void (*time_passes)(uint64_t until);            /* the board's time is about to move on to 'until': the
	                                                   sound board runs up to then */
	void (*sound_irq_changed)(bool asserted, uint8_t vector);   /* interrupt line to the Z80 */
	void (*sound_reset_changed)(bool held);         /* the I/O chip's CNT2 output holds the Z80 in reset */
	void (*log)(const char *message);
} s32_machine;

extern s32_machine s32_board;

void s32_init(const uint8_t *program);
void s32_reset(void);

uint8_t s32_read8(uint32_t address);
uint16_t s32_read16(uint32_t address);
uint32_t s32_read32(uint32_t address);
void s32_write8(uint32_t address, uint8_t data);
void s32_write16(uint32_t address, uint16_t data);
void s32_write32(uint32_t address, uint32_t data);

void s32_signal_irq(int source);
bool s32_irq_asserted(void);
uint8_t s32_irq_acknowledge(void);

uint64_t s32_next_timer(void);
void s32_run_timers(void);

void s32_vblank_start(void);
void s32_vblank_end(void);
void s32_sprite_update(void);   /* MAME runs it 50 us after the end of VBLANK */

/* The Z80's side of the sound board (sound.c): its memory (the program, the banked page of the sound
   ROM, the RF5C68 and the shared RAM) and its I/O ports (the YM3438s, the bank, the interrupt
   controller) */
uint8_t s32_z80_read(uint16_t address);
void s32_z80_write(uint16_t address, uint8_t data);
uint8_t s32_z80_in(uint8_t port);
void s32_z80_out(uint8_t port, uint8_t data);
void s32_sound_signal_irq(int input);
void s32_sound_clear_irq(int input);

/* Board time when a frame starts (VBLANK ends) and when one of its lines starts */
uint64_t s32_frame_start(uint64_t frame);
uint64_t s32_line_start(uint64_t frame, int line);

/* Frame timing: the program waits, the board runs its next event (it may raise an interrupt) */
void s32_wait(void);

/* Hash of the state a frame leaves behind: work RAM but the stacks, video RAM, sprite RAM, palette
   and mixer (FNV-1a, 64 bits) */
uint64_t s32_state_hash(void);

#ifdef __cplusplus
}
#endif

#endif
