/**
 *    Name:        make_psp_pack.c
 *    Description: writes the PSP's pack, segasonic.psp, from the game's assets pack: the board's four ROM
 *                 regions as the console game's video reads them (the console's changes to the sprites made),
 *                 in 4 KB blocks, LZ4-compressed, raw or fills (runtime/src/sprite_pager.c has the format)
 *    Version:     0.1.0
 *    Created:     26-10-2026
 *    Modified:    26-10-2026
 *
 *    license:BSD-3-Clause
 *    Usage: make_psp_pack segasonic.assets segasonic.psp
 *    The pack is made from the player's ROM set, as segasonic.assets: it is the player's, never to share.
 */
#include "game/data.h"
#include "s32/sprite_pager.h"
#include "console.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define BLOCK       S32_PAGER_BLOCK
#define HASH_BITS   13
#define CHAIN_DEPTH 48

/* LZ4's block format, a hash chain over the block's own bytes: the compressed size, or 0 when it does not
   fit in 'limit' */
static size_t lz4_compress(const uint8_t *in, size_t size, uint8_t *out, size_t limit)
{
	static int head[1 << HASH_BITS];
	int chain[BLOCK];
	size_t pos = 0, anchor = 0, written = 0;

	for (size_t i = 0; i < (1u << HASH_BITS); i++)
		head[i] = -1;
#define PUT(byte) do { if (written >= limit) return 0; out[written++] = (uint8_t)(byte); } while (0)
	while (pos + 12 <= size)
	{
		const uint32_t sequence = (uint32_t)in[pos] | (uint32_t)in[pos + 1] << 8 | (uint32_t)in[pos + 2] << 16
			| (uint32_t)in[pos + 3] << 24;
		const uint32_t hash = (sequence * 2654435761u) >> (32 - HASH_BITS);
		size_t best = 0, best_from = 0;
		int candidate = head[hash], depth = 0;

		while (candidate >= 0 && depth++ < CHAIN_DEPTH)
		{
			size_t length = 0;

			while (pos + length < size - 5 && in[candidate + length] == in[pos + length])
				length++;
			if (length > best)
			{
				best = length;
				best_from = (size_t)candidate;
			}
			candidate = chain[candidate];
		}
		chain[pos] = head[hash];
		head[hash] = (int)pos;
		if (best >= 4)
		{
			const size_t literals = pos - anchor, offset = pos - best_from;
			size_t rest = best - 4;

			PUT((literals >= 15 ? 15 : literals) << 4 | (rest >= 15 ? 15 : rest));
			if (literals >= 15)
			{
				size_t more = literals - 15;

				for (; more >= 255; more -= 255)
					PUT(255);
				PUT(more);
			}
			if (written + literals > limit)
				return 0;
			memcpy(out + written, in + anchor, literals);
			written += literals;
			PUT(offset & 255);
			PUT(offset >> 8);
			if (rest >= 15)
			{
				rest -= 15;
				for (; rest >= 255; rest -= 255)
					PUT(255);
				PUT(rest);
			}
			for (size_t skipped = 1; skipped < best; skipped++)    /* (the bytes the match covers join the chains) */
			{
				const size_t at = pos + skipped;

				if (at + 4 <= size)
				{
					const uint32_t s = (uint32_t)in[at] | (uint32_t)in[at + 1] << 8 | (uint32_t)in[at + 2] << 16
						| (uint32_t)in[at + 3] << 24;
					const uint32_t h = (s * 2654435761u) >> (32 - HASH_BITS);

					chain[at] = head[h];
					head[h] = (int)at;
				}
			}
			pos += best;
			anchor = pos;
		}
		else
			pos++;
	}
	{
		const size_t literals = size - anchor;

		PUT((literals >= 15 ? 15 : literals) << 4);
		if (literals >= 15)
		{
			size_t more = literals - 15;

			for (; more >= 255; more -= 255)
				PUT(255);
			PUT(more);
		}
		if (written + literals > limit)
			return 0;
		memcpy(out + written, in + anchor, literals);
		written += literals;
	}
#undef PUT
	return written;
}

int main(int argc, char **argv)
{
	const uint32_t total = (GAME_PROGRAM_SIZE + GAME_TILES_SIZE + GAME_SOUND_SIZE + GAME_SPRITES_SIZE) / BLOCK;
	const uint8_t *regions[4] = { game_program, game_tiles, game_sound, game_sprites };
	const uint32_t sizes[4] = { GAME_PROGRAM_SIZE, GAME_TILES_SIZE, GAME_SOUND_SIZE, GAME_SPRITES_SIZE };
	uint8_t *index, *body;
	size_t body_size = 0, base;
	uint32_t number = 0, lz4_blocks = 0, raw_blocks = 0, fill_blocks = 0;
	FILE *out;
	uint8_t head[16] = { 'S', 'S', 'P', 'P', 1, 0, 0, 0, 0, 0x10, 0, 0, 0, 0, 0, 0 };
	uint8_t packed[BLOCK + 64];

	if (argc != 3)
	{
		fprintf(stderr, "Usage: make_psp_pack segasonic.assets segasonic.psp\n");
		return 2;
	}
	if (game_data_load(argv[1]) != GAME_DATA_LOADED)
	{
		fprintf(stderr, "%s: the assets cannot be read\n", argv[1]);
		return 1;
	}
	console_prepare_sprites(game_sprites, GAME_SPRITES_SIZE, game_program);
	head[12] = (uint8_t)total;
	head[13] = (uint8_t)(total >> 8);
	head[14] = (uint8_t)(total >> 16);
	index = (uint8_t *)calloc(total, 8);
	body = (uint8_t *)malloc((size_t)total * BLOCK);
	base = 16 + (size_t)total * 8;
	for (int region = 0; region < 4; region++)
		for (uint32_t offset = 0; offset < sizes[region]; offset += BLOCK, number++)
		{
			const uint8_t *block = regions[region] + offset;
			uint8_t *entry = index + (size_t)number * 8;
			size_t same = 1, size;
			uint32_t at = (uint32_t)(base + body_size);

			while (same < BLOCK && block[same] == block[0])
				same++;
			if (same == BLOCK)
			{
				entry[6] = 2;
				entry[7] = block[0];
				fill_blocks++;
				continue;
			}
			size = lz4_compress(block, BLOCK, packed, BLOCK - 1);
			if (size)
			{
				memcpy(body + body_size, packed, size);
				entry[6] = 0;
				lz4_blocks++;
			}
			else
			{
				size = BLOCK;
				memcpy(body + body_size, block, BLOCK);
				entry[6] = 1;
				raw_blocks++;
			}
			entry[0] = (uint8_t)at;
			entry[1] = (uint8_t)(at >> 8);
			entry[2] = (uint8_t)(at >> 16);
			entry[3] = (uint8_t)(at >> 24);
			entry[4] = (uint8_t)size;
			entry[5] = (uint8_t)(size >> 8);
			body_size += size;
		}
	out = fopen(argv[2], "wb");
	if (!out || fwrite(head, 1, 16, out) != 16 || fwrite(index, 8, total, out) != total
		|| fwrite(body, 1, body_size, out) != body_size || fclose(out) != 0)
	{
		fprintf(stderr, "%s: cannot be written\n", argv[2]);
		return 1;
	}
	printf("%s: %u blocks (%u lz4, %u raw, %u fill), %zu bytes\n", argv[2], total, lz4_blocks, raw_blocks, fill_blocks,
		base + body_size);
	return 0;
}
