# SegaSonic The Hedgehog: PSP port, Source 1.2 (changes on top of segasonic-port-1.2.2)

Licence: BSD 3-Clause, as the original port (see LICENSE). No ROM data and no game assets are included: use your own
ROM dump (`rom/`) and extract the assets with `extract_assets.py`, as the original README says.

What this source has
- `ports/psp/`, `ports/sdl2/` (`#ifdef __PSP__`), `CMakeLists.txt` PSP guards: EBOOT/PRX with pspdev (SDL2).
- `runtime/src/sprite_pager.c`, `tools/make_psp_pack.c`: sprite pack `segasonic.psp` (4 KB blocks, LZ4) to fit 24 MB.
  Make it from YOUR assets; do not share it.
- `runtime/src/video.c`: faster layers/mixer/sprites (bit-exact at full resolution, checked by frame hashes), picture
  planning, options `half_lines` (every other line, the text layer stays sharp) and `half_columns` (every other column).
- `runtime/src/ym3438.c`, `sound_chips.c`: FM at half, quarter and eighth rate (eighth on by default on the PSP).
- Settings in `segasonic.ini`: frame_skip (0 auto, 1-4), half_lines, half_columns, fm_half_rate, fm_quarter_rate,
  fm_eighth_rate, volume.
- Built with -O3 -G0 (faster than -O2 here; -funroll-loops and LTO were not better or did not link).

Build (pspdev toolchain):
    export PSPDEV=/path/to/pspdev PATH=$PSPDEV/bin:$PATH
    cmake -S . -B build/psp -DCMAKE_TOOLCHAIN_FILE=$PSPDEV/psp/share/pspdev.cmake -DCMAKE_BUILD_TYPE=Release -DCMAKE_C_FLAGS_RELEASE="-O3 -G0"
    cmake --build build/psp --target SegaSonic
Put EBOOT.PBP and segasonic.psp in ms0:/PSP/GAME/SegaSonic/.
